function swapCase(str) {
  var result = "";

  for (var i = 0; i < str.length; i++) {
    var ch = str[i];

    if (ch === ch.toUpperCase()) {
      result += ch.toLowerCase();
    } else {
      result += ch.toUpperCase();
    }
  }

  return result;
}

var text = "Hello World";
console.log(swapCase(text));