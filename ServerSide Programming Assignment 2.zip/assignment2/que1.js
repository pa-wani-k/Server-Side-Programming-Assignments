function findWordIndexes(str, word) {
  let indexes = [];
  let index = str.indexOf(word);

  while (index !== -1) {
    indexes.push(index);
    index = str.indexOf(word, index + 1);
  }

  return indexes;
}

let text = "JavaScript is great. I love JavaScript because JavaScript is powerful.";
let word = "JavaScript";

console.log(findWordIndexes(text, word));