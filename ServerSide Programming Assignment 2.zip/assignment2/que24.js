try {
  let jsonString = '{"name": "John", "age": 30,';  

  let data = JSON.parse(jsonString);

  console.log(data);
} 
catch (error) {
  if (error instanceof SyntaxError) {
    console.log("SyntaxError caught: Invalid JSON format.");
  } else {
    console.log("Error:", error.message);
  }
}