function parseURL(url) {
  var parser = document.createElement('a');
  parser.href = url;

  return {
    protocol: parser.protocol,
    host: parser.host,
    hostname: parser.hostname,
    port: parser.port,
    pathname: parser.pathname,
    search: parser.search,
    hash: parser.hash
  };
}

var url = "https://www.example.com:8080/path/page.html?name=test#section";
var result = parseURL(url);

console.log(result);