class Stack {
  constructor() {
    this.items = [];
  }

  push(element) {
    this.items.push(element);
  }

  pop() {
    return this.items.pop();
  }

  contains(element) {
    return this.items.includes(element);
  }

  display() {
    console.log(this.items);
  }
}

let stack = new Stack();

stack.push(10);
stack.push(20);
stack.push(30);
stack.push(40);

console.log("Stack elements:");
stack.display();

let element = 20;

if (stack.contains(element)) {
  console.log(element + " is present in the stack.");
} else {
  console.log(element + " is not present in the stack.");
}