function timeConvert(num) {
  var hours = Math.floor(num / 60);
  var minutes = num % 60;

  return num + " minutes = " + hours + " hour(s) and " + minutes + " minute(s).";
}

console.log(timeConvert(200));