function linearSearch(arr,target){
    for(let i=0;i<arr.length;i++){
        if(arr[i]===target) return i;
    }
    return -1;
}
let fruits =["apple","banana","mango"];
let result=linearSearch(fruits,"mango");

if(result !==-1){
    console.log(result);
}
else{
    console.log("element not found");
}