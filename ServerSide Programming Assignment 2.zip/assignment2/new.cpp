#include <stdio.h>
#include <vector>
using namespace std;

int solve(vector<int>& arr, int start, int end) {
    int total = 0;

    for (int i = start; i <= end; i++) {
        total += arr[i];
    }

    // If sum is odd → cannot split
    if (total % 2 != 0) return 0;

    int prefix = 0;

    for (int i = start; i < end; i++) {
        prefix += arr[i];

        if (prefix == total / 2) {
            int left = solve(arr, start, i);
            int right = solve(arr, i + 1, end);

            return 1 + (left > right ? left : right);
        }
    }

    return 0;
}

int maximumSplits(int input1, int input2[]) {
    vector<int> arr(input1);

    for (int i = 0; i < input1; i++) {
        arr[i] = input2[i];
    }

    return solve(arr, 0, input1 - 1);
}