function isSorted(arr) {
  for (let i = 1; i < arr.length; i++) {
    if (arr[i] < arr[i - 1]) {
      return false; 
    }
  }
  return true; 
}

let numbers = [1, 2, 3, 4, 5];

let result = isSorted(numbers);
if(result){
    console.log("sorted");
}else{
    console.log("not sorted");
}