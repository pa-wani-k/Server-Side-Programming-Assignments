function isNull(value) {
  if (value === null) {
    return true;
  }
  return false;
}
console.log(isNull(null));  
console.log(isNull(5));      
console.log(isNull(""));     
console.log(isNull(undefined));    