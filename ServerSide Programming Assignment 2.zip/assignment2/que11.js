function isNumber(value) {
  if (typeof value === "number" && !isNaN(value)) {
    return true;
  }
  return false;
}
console.log(isNumber(25));      
console.log(isNumber("25"));    
console.log(isNumber(NaN));   
console.log(isNumber(3.14)); 