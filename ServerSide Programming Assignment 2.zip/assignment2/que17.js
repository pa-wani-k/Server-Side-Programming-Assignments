function stringToArray(str) {
  return str.split(" ");
}

// Example usage
var text = "JavaScript is very powerful";
var result = stringToArray(text);

console.log(result);